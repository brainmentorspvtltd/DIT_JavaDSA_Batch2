package com.bmpl.chatapp.dto;

public class UserDTO {
	private String userId;
	private char []password;
	public UserDTO(String userid, char []password) {
		this.userId = userid;
		this.password = password;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public char[] getPassword() {
		return password;
	}
	public void setPassword(char[] password) {
		this.password = password;
	}
	
}
