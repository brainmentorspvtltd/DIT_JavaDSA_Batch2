public class StringDemo {

	public static void main(String[] args) {
		
		String name = "Ravi";
		String name2 = "Ravi";
		
		System.out.println(name == name2);		// checking reference
		System.out.println(name.equals(name2)); // checking value
		
		String name3 = new String("Ravi");
		System.out.println(name == name3);
		System.out.println(name.equals(name3));	// checking value only
		
		String text = "Hello World";
		text = "Bye World...";			// it will create new memory
		System.out.println(text);
		
		
//		StringBuffer sb = new StringBuffer();
//		// it creates an array of 16 size...
//		System.out.println(sb.capacity() + ", " + sb.length());
//		sb.append("Hello World");
//		System.out.println(sb.capacity() + ", " + sb.length());
//		sb.append("How are you ?");
//		System.out.println(sb.capacity() + ", " + sb.length());
		
//		if string buffer is full,
//		old_capacity * 2 + 2
//		+2 for null character
		
//		sb.append("---- In string pool it also checks whether string already exists or not..If there is no existing object with same value then It creates the object in pool and also a copy of it...");
//		System.out.println(sb.capacity() + ", " + sb.length());
		
		// fixed buffer size
//		StringBuffer sb = new StringBuffer(200);
//		System.out.println(sb.capacity() + ", " + sb.length());
//		sb.append("Hello World");
//		System.out.println(sb.capacity() + ", " + sb.length());
//		System.out.println(sb.capacity() + ", " + sb.length());
//		
//		sb.append("--------------- In string pool it also checks whether string already exists or not..If there is no existing object with same value then It creates the object in pool and also a copy of it...");
//		System.out.println(sb.capacity() + ", " + sb.length());
		
		StringBuilder sb = new StringBuilder();
		System.out.println(sb.capacity() + ", " + sb.length());
		sb.append("Hello World");
		System.out.println(sb.capacity() + ", " + sb.length());
	}

}
