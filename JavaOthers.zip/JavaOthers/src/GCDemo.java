class A {
	int x, y;
	public A(int x, int y) {
		this.x = x;
		this.y = y;
		System.out.println("New Object Born...");
	}
	
	@Override
	protected void finalize() {
		System.out.println("Object Destroyed...");
	}
	
}

public class GCDemo {

	public static void main(String[] args) {
		
		A obj = new A(10,20);
		obj = null;	// 1st way
		
		System.gc();
		for(int i = 1; i <= 10; i++) {
			System.out.println("I is : " + i );
		}
		
//		A obj2 = new A(12,55);
//		A obj3 = new A(11,57);
//		obj3 = obj2;	// 2nd way
		
		// 3rd way
//		if(20 > 10) {
//			A obj4 = new A(11,51);
			// outside the scope it is eligible for garbage collection
//		}

	}

}
