import java.util.LinkedList;

class Mem {
	String t;
	int e;
	public Mem(String t, int e) {
		this.t = t;
		this.e = e;
	}
}


public class FullMemory {

	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("Program Started...");
		LinkedList l = new LinkedList<>();
		int i = 1;
		while(true) {
			Mem obj = new Mem("Hello",12);
			System.out.println(i);
			l.add(obj);
			i++;
//			Thread.sleep(30);
		}

	}

}
