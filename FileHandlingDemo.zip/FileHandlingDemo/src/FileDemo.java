import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		
		String path = "D:\\Trainings\\DIT_2022\\java_classes.txt";
		File file = new File(path);
		if(file.exists()) {
//			file.delete();
//			System.out.println("File Delete...");
			File file2 = new File("D:\\Trainings\\DIT_2022\\java_classes_2.txt");
			file.renameTo(file2);
			System.out.println("File Renamed...");
		}
		else {
			file.createNewFile();
			System.out.println("File Created...");
		}
		
		System.out.println(file.getAbsolutePath());
		System.out.println(file.getName());
		
		file = new File("D:\\Trainings\\DIT_2022\\xx\\yy\\zz");
		file.mkdirs();
		
		file = new File("D:\\Trainings\\DIT_2022");
		File files[] = file.listFiles();
		System.out.println("Number of files and folder : " + files.length);

	}

}
