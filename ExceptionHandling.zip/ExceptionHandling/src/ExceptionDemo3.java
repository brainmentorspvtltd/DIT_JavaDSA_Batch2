public class ExceptionDemo3 {
	
	static void dao() throws ArithmeticException {
		System.out.println("Connection Open...");
		
		try {
			int e = 23/0;
			System.out.println("Query triggered");
			System.out.println("Sending result to helper...");
		}
		finally {
			System.out.println("Connection Close...");
		}
	}
	
	static void helper() throws ArithmeticException {
		System.out.println("Calling DAO...");
		dao();
		System.out.println("Fetching data from DAO...");
		System.out.println("Sending output to view...");
	}
	
	static void view() {
		System.out.println("Calling Helper...");
		try {
			helper();
			System.out.println("Fetching results from helper...");
			System.out.println("Show results to user...");
		}
		
		catch (ArithmeticException e) {
			System.out.println("Got some error...");
		}
		
	}

	public static void main(String[] args) {
		
		view();

	}

}
