import java.util.InputMismatchException;
import java.util.Scanner;

public class CalcDemo {
	Scanner scanner = new Scanner(System.in);
	int fnum;
	int snum;
	int result;

	void takeFirstNumber() {
		try {
			System.out.print("Enter first number : ");
			fnum = scanner.nextInt();		// throw new InputMismatchException
		}
		catch(InputMismatchException e) {
			System.out.println("Invalid Input...");
			System.out.println(scanner.nextLine());
			takeFirstNumber();
		}
	}
	
	void takeSecondNumber() {
		try {
			System.out.print("Enter second number : ");
			snum = scanner.nextInt();		// throw new InputMismatchException
		}
		catch(InputMismatchException e) {
			System.out.println("Invalid Input...");
			System.out.println(scanner.nextLine());
			takeSecondNumber();
		}
	}
	
	void addition() {
		try {
			result = fnum + snum;
		}
		catch(ArithmeticException e) {
			System.out.println("Error during addition...");
		}
	}
	
	void subtraction() {
		try {
			result = fnum - snum;
		}
		catch(ArithmeticException e) {
			System.out.println("Error during subtraction...");
		}	
	}
	
	void division() {
		try {
			result = fnum / snum;
		}
		catch(ArithmeticException e) {
			System.out.println("Error during division...");
			System.out.println("Cannot divide by zero...");
			takeSecondNumber();
			division();
		}
	}
	
	void print() {
		System.out.println("Result is : "+result);
	}
	
	void closeScanner() {
		scanner.close();
	}

	public static void main(String[] args) {
		
		CalcDemo obj = new CalcDemo();
		obj.takeFirstNumber();
		obj.takeSecondNumber();
		obj.addition();
		obj.subtraction();
		obj.division();
		obj.print();
		obj.closeScanner();

	}

}
