import java.util.Scanner;

// Checked Exception
//class CheckedException extends Exception {
//	
//}

class CheckAgeException extends RuntimeException {
	String message;
	public CheckAgeException() {
		this.message = "";
	}
	
	public CheckAgeException(String msg) {
		this.message = msg;
	}
	
	@Override
	public String toString() {
		return "CheckAgeException [message = " + message + "]";
	}
}

public class UserDefinedException {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your age : ");
		int age = scanner.nextInt();
		
		try {
			if(age > 18) {
				System.out.println("You can register...");
			}
			else {
				throw new CheckAgeException("Age cannot be less than 18...");
			}
		}
		catch (CheckAgeException e) {
			System.err.println(e);
		}
		finally {
			scanner.close();
		}

	}

}
