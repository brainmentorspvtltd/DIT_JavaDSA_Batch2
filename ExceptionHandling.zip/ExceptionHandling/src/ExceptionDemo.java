import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {

	public static void main(String[] args) {
		
		System.out.println("Program Started...");
		System.out.println("Database Connection Established...");
		Scanner scanner = new Scanner(System.in);
		
		try {
			System.out.print("Enter first number : ");
			int x = scanner.nextInt();
			
			System.out.print("Enter second number : ");
			int y = scanner.nextInt();
			
			int add = x + y;
			System.out.println("Sum is : " + add);
			int sub = x - y;
			System.out.println("Sub is : " + sub);
			float div = x / y;
			System.out.println("Div is : " + div);
			int mul = x * y;
			System.out.println("Mul is : " + mul);
			
			System.out.println("Fetching data from user...");
			System.out.println("Sending data to server...");
			
			int arr[] = new int[5];
			arr[9] = 12;
			
		}
		
		catch (ArithmeticException e) {
			System.err.println("Cannot divide by zero...");
		}
		
		catch (InputMismatchException e) {
			System.err.println("Invalid Input...");	
		}
		
		catch (ArrayIndexOutOfBoundsException e) {
//			System.err.println(e);
			System.err.println("Some Error...");
		}
		
		catch (Exception e) {
			System.out.println(e);
		}
		
		scanner.close();

	}

}
