import java.io.File;
import java.io.IOException;

public class ExceptionDemo2 {

	public static void main(String[] args) {
		
		try {
			String path = "demo.txt";
			File file = new File(path);
			if(file.exists()) {
				System.out.println("File already exists...");
			}
			else {
				file.createNewFile();
				System.out.println("File Created...");
			}
		}
		catch(NullPointerException e) {
			System.out.println("String is null...");
		}
		catch(IOException e) {
			System.out.println("File Not Created...");
		}

	}

}
